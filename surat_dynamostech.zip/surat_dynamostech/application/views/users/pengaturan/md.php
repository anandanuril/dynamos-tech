<!-- Main content -->
<div class="content-wrapper">
    <!-- Content area -->
    <div class="content">
        <?php
        echo $this->session->flashdata('msg');

        $is_admin = ($this->session->userdata('level') == 's_admin');
        $readonly = $is_admin ? '' : 'readonly';

        ?>
        <!-- Dashboard content -->
        <div class="row">
            <div class="col-md-12">
                <!-- Basic datatable -->
                <?php if ($user->row()->level == 's_admin') { ?>
                    <div class="panel">
                        <div class="panel-heading text-left">
                            <div class="row">
                                <div class="col-sm-6 text-left">
                                    <span class="glyphicon glyphicon-home" aria-hidden="true"></span><b class="">&nbsp; PROFIL PERUSAHAAN</b><br><?php echo $md->nama_pt; ?>
                                </div>
                            </div>
                            <hr>
                        </div>
                        <div class="panel-body">
                            <fieldset class="content-group">
                                <form class="form-horizontal" action="" method="post">
                                    <div class="form-group">
                                        <label class="control-label col-lg-2 text-right">Nama Perusahaan</label>
                                        <div class="col-lg-4">
                                            <div class="input-group">
                                                <span class="input-group-addon"><i class="icon-home"></i></span>
                                                <input type="hidden" name="id" class="form-control" placeholder="Masukkan Nama Perusahaan" value="<?php echo $md->id; ?>">
                                                <input type="text" name="nama_pt" class="form-control" placeholder="Masukkan Nama Perusahaan" value="<?php echo $md->nama_pt; ?>">
                                            </div>
                                        </div>

                                        <label class="control-label col-lg-2 text-right">Nama</label>
                                        <div class="col-lg-4">
                                            <div class="input-group">
                                                <span class="input-group-addon"><i class="icon-user"></i></span>
                                                <input type="text" name="nama" class="form-control" placeholder="Masukkan Nama" value="<?php echo $md->nama; ?>">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="control-label col-lg-2 text-right">Deskripsi</label>
                                        <div class="col-lg-4">
                                            <div class="input-group">
                                                <span class="input-group-addon"><i class="icon-list"></i></span>
                                                <input type="text" name="deskripsi" class="form-control" placeholder="Masukkan Deskripsi" value="<?php echo $md->deskripsi; ?>">
                                            </div>
                                        </div>
                                        <label class="control-label col-lg-2 text-right">Jabatan</label>
                                        <div class="col-lg-4">
                                            <div class="input-group">
                                                <span class="input-group-addon"><i class="icon-pencil"></i></span>
                                                <input type="text" name="jabatan" class="form-control" placeholder="Masukkan Jabatan" value="<?php echo $md->jabatan; ?>">
                                            </div>
                                        </div>
                                    </div>


                                    <hr>
                                    <div class="form-group">
                                        <label class="control-label col-lg-2 text-right">KOP PERTAMA</label>
                                        <div class="col-lg-4">
                                            <div class="input-group">
                                                <span class="input-group-addon"><i class="icon-list"></i></span>
                                                <input type="text" name="kop_1" class="form-control" placeholder="Masukkan KOP Pertama" value="<?php echo $md->kop_1; ?>">
                                            </div>
                                        </div>

                                        <label class="control-label col-lg-2 text-right">KOP KEDUA</label>
                                        <div class="col-lg-4">
                                            <div class="input-group">
                                                <span class="input-group-addon"><i class="icon-list"></i></span>
                                                <input type="text" name="kop_2" class="form-control" placeholder="Masukkan KOP Kedua" value="<?php echo $md->kop_2; ?>">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="control-label col-lg-2 text-right">Kontak</label>
                                        <div class="col-lg-4">
                                            <div class="input-group">
                                                <span class="input-group-addon"><i class="icon-list"></i></span>
                                                <textarea name="kontak" class="form-control" placeholder="Masukkan Kontak"><?php echo $md->kontak; ?></textarea>
                                            </div>
                                        </div>
                                        <label class="control-label col-lg-2 text-right">Alamat</label>
                                        <div class="col-lg-4">
                                            <div class="input-group">
                                                <span class="input-group-addon"><i class="icon-list"></i></span>
                                                <textarea name="alamat" class="form-control" placeholder="Masukkan Alamat Lengkap"><?php echo $md->alamat; ?></textarea>
                                            </div>
                                        </div>
                                    </div>
                                    <div style="float: right;">
                                        <a href="users/" class="btn btn-xs btn-danger">
                                            <span class="glyphicon glyphicon-circle-arrow-left"></span>&nbsp;<b>KEMBALI</b>
                                        </a>
                                        <button type="submit" name="btnupdate" class="btn btn-xs btn-primary">
                                            <span class="glyphicon glyphicon-floppy-saved"></span>&nbsp;<b>SIMPAN DATA</b>
                                        </button>
                                    </div>

                                </form>
                            </fieldset>
                        </div>
                    </div>

                <?php } else { ?>
                    <div class="panel">
                        <div class="panel-heading text-left">
                            <div class="row">
                                <div class="col-sm-6 text-left">
                                    <span class="glyphicon glyphicon-home" aria-hidden="true"></span><b class="">&nbsp; PROFIL PERUSAHAAN</b><br><?php echo $md->nama_pt; ?>
                                </div>
                            </div>
                            <hr>
                        </div>
                        <div class="panel-body">
                            <fieldset class="content-group">
                                <form class="form-horizontal" action="" method="post">
                                    <div class="form-group">
                                        <label class="control-label col-lg-2 text-right">Nama Perusahaan</label>
                                        <div class="col-lg-4">
                                            <div class="input-group">
                                                <span class="input-group-addon"><i class="icon-home"></i></span>
                                                <input type="hidden" name="id" class="form-control" placeholder="Masukkan Nama Perusahaan" value="<?php echo $md->id; ?>">
                                                <input type="text" name="nama_pt" class="form-control" placeholder="Masukkan Nama Perusahaan" value="<?php echo $md->nama_pt; ?>" <?php echo $readonly; ?>>
                                            </div>
                                        </div>

                                        <label class="control-label col-lg-2 text-right">Nama</label>
                                        <div class="col-lg-4">
                                            <div class="input-group">
                                                <span class="input-group-addon"><i class="icon-user"></i></span>
                                                <input type="text" name="nama" class="form-control" placeholder="Masukkan Nama" value="<?php echo $md->nama; ?>" <?php echo $readonly; ?>>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="control-label col-lg-2 text-right">Deskripsi</label>
                                        <div class="col-lg-4">
                                            <div class="input-group">
                                                <span class="input-group-addon"><i class="icon-list"></i></span>
                                                <input type="text" name="deskripsi" class="form-control" placeholder="Masukkan Deskripsi" value="<?php echo $md->deskripsi; ?>" <?php echo $readonly; ?>>
                                            </div>
                                        </div>
                                        <label class="control-label col-lg-2 text-right">Jabatan</label>
                                        <div class="col-lg-4">
                                            <div class="input-group">
                                                <span class="input-group-addon"><i class="icon-pencil"></i></span>
                                                <input type="text" name="jabatan" class="form-control" placeholder="Masukkan Jabatan" value="<?php echo $md->jabatan; ?>" <?php echo $readonly; ?>>
                                            </div>
                                        </div>
                                    </div>


                                    <hr>
                                    <div class="form-group">
                                        <label class="control-label col-lg-2 text-right">KOP PERTAMA</label>
                                        <div class="col-lg-4">
                                            <div class="input-group">
                                                <span class="input-group-addon"><i class="icon-list"></i></span>
                                                <input type="text" name="kop_1" class="form-control" placeholder="Masukkan KOP Pertama" value="<?php echo $md->kop_1; ?>" <?php echo $readonly; ?>>
                                            </div>
                                        </div>

                                        <label class="control-label col-lg-2 text-right">KOP KEDUA</label>
                                        <div class="col-lg-4">
                                            <div class="input-group">
                                                <span class="input-group-addon"><i class="icon-list"></i></span>
                                                <input type="text" name="kop_2" class="form-control" placeholder="Masukkan KOP Kedua" value="<?php echo $md->kop_2; ?>" <?php echo $readonly; ?>>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="control-label col-lg-2 text-right">Kontak</label>
                                        <div class="col-lg-4">
                                            <div class="input-group">
                                                <span class="input-group-addon"><i class="icon-list"></i></span>
                                                <textarea name="kontak" class="form-control" placeholder="Masukkan Telepon dan Email" <?php echo $readonly; ?>><?php echo $md->kontak; ?></textarea>
                                            </div>
                                        </div>
                                        <label class="control-label col-lg-2 text-right">Alamat</label>
                                        <div class="col-lg-4">
                                            <div class="input-group">
                                                <span class="input-group-addon"><i class="icon-list"></i></span>
                                                <textarea name="alamat" class="form-control" placeholder="Masukkan Alamat Lengkap" <?php echo $readonly; ?>><?php echo $md->alamat; ?></textarea>
                                            </div>
                                        </div>
                                    </div>
                                    <div style="float: right;">
                                        <a href="users/" class="btn btn-xs btn-danger">
                                            <span class="glyphicon glyphicon-circle-arrow-left"></span>&nbsp;<b>KEMBALI</b>
                                        </a>
                                        <?php if ($user->row()->level == 's_admin') { ?>
                                            <button type="submit" name="btnupdate" class="btn btn-xs btn-primary">
                                                <span class="glyphicon glyphicon-floppy-saved"></span>&nbsp;<b>SIMPAN DATA</b>
                                            </button>
                                        <?php } ?>
                                    </div>

                                </form>
                            </fieldset>
                        </div>
                    </div>

                <?php } ?>
            </div>
            <!-- /basic datatable -->
        </div>
        <!-- /dashboard content -->