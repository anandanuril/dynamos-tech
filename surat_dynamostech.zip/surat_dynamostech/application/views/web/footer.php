<!-- Footer -->
<div class="footer text-muted text-center">
	<a href="" class="text-danger"><b>PT Dynamos Tech</b></a> &copy; 2025
</div>
<!-- /footer -->
</div>
<!-- /content area -->
</div>
<!-- /main content -->
</div>
<!-- /page content -->
</div>
<!-- /page container -->
</body>

</html>