<div class="kontainer">
	<div class="kotak">
		<?php echo $this->session->flashdata('msg'); ?>
		<div class="wrapper">
			<p style="padding: 20px 10px; text-align-last: center; font-size: 15px; font-weight: bold;">
				<img src="<?php echo base_url('foto/default.jpg') ?>" style="width: 100px; height: auto;">
				<br>
				<br>ARSIP SURAT DIGITAL
				<br>PT Dynamos Tech
			</p>

			<div class="title1"><span>LOGIN</span></div>
			<form action="" method="post">
				<div class="row">
					<i class="icon-user-lock"></i>
					<input type="text" required="" autofocus="" name="username" placeholder="Username" class="form-control flat">
				</div>
				<div class="row">
					<i class="icon-lock2"></i>
					<input type="password" required="" name="password" placeholder="Password" class="form-control flat">
				</div>
				<div class="row text-right" style="margin-bottom: -12px;">
					<button type="submit" name="btnlogin" class="btn btn-login"><span class="fa fa-random"></span> &nbsp;<b>LOGIN</b></button>
				</div>
			</form>
		</div>
		<br>