/* ------------------------------------------------------------------------------
*
*  # Job search - list
*
*  Specific JS code additions for job search page kit - list view
*
*  Version: 1.0
*  Latest update: Jan 10, 2017
*
* ---------------------------------------------------------------------------- */

$(function() {

    // Checkboxes, radios
    $(".styled, .multiselect-container input").uniform({
        radioClass: 'choice'
    });
  
});
